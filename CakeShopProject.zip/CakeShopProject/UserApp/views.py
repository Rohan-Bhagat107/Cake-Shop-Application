from django.shortcuts import render,redirect
from django.http import HttpResponse
from AdminApp.models import Category,Cake,Payment
from UserApp.models import UserInfo,MyCart
# Create your views here.
def home(request):
    cats=Category.objects.all()
    cakes=Cake.objects.all()
    return render(request,"home.html",{"cats":cats,"cakes":cakes})

def viewCakes(request,cid):
    #For .filter() or .get() we always need objects, not specific values of id
    cat=Category.objects.get(id=cid)
    cakes=Cake.objects.filter(category=cat)
    cats=Category.objects.all()
    return render(request,"home.html",{"cats":cats,"cakes":cakes})
def ViewDetails(request,cid):
    if request.method=="GET":
        cake=Cake.objects.get(id=cid)
        cats=Category.objects.all()
        return render(request,"ViewDetails.html",{"cake":cake,"cats":cats})
    else:
        # check if user hass loged in or not
        if "uname" in request.session:
            #add to cart
            cake_id=request.POST["cake_id"]
            qty=request.POST["qty"]
            uname=request.session["uname"]
            cake=Cake.objects.get(id=cid)
            user=UserInfo.objects.get(username=uname)
            try:
                cart=MyCart.objects.get(user=user,cake=cake,qty=qty)
            except:
                cart=MyCart(cake=cake,user=user,qty=qty)
                cart.save()
            else:
                return HttpResponse("This item is already present in the cart")  
            return redirect(home)  
        else:
            return redirect("/login")
def Login(request):
    if request.method=="GET":
        return render(request,"login.html")
    else:
        uname=request.POST["uname"]
        pwd=request.POST["pwd"]
        try:
            user=UserInfo.objects.get(username=uname,password=pwd)
        except:
            return redirect("/login")
        else:
            #adding username into the session
            request.session["uname"]=uname
            return redirect(home)
def SignUp(request):
    if request.method=="GET":
        return render(request,"SignUp.html")
    else:
        uname=request.POST["uname"]
        pwd=request.POST["pwd"]
        email=request.POST["email"]
        # Check if username is already p resent or not 
        try:
            user=UserInfo(uname,pwd,email)
        except:
            user.save()
            return redirect(home)
        else:
            return HttpResponse("This Username is already Present")
        

def Verify(request):
    if request.method=="GET":
        return render(request,"verifyUsername.html")
    else:
        uname=request.POST["uname"]
        email=request.POST["email"]
        # print(uname,email)
        try:
            
            user=UserInfo.objects.get(username=uname,Email=email)
            
        except:
            # print(user)
            return redirect(SignUp)
        else:
            return redirect(ResetPassword)

def ResetPassword(request):
    if request.method=="GET":
        return render(request,"resetPassword.html")
    else:
        uname=request.POST["uname"]
        pwd=request.POST["pwd"]
        user=UserInfo.objects.get(username=uname,password=pwd)
        user.save()
        return redirect(login)


def Logout(request):
    request.session.clear()
    return redirect(home)

def showCart(request):
    cats=Category.objects.all()
    if request.method=="GET":

        user=UserInfo.objects.get(username=request.session["uname"])
        items=MyCart.objects.filter(user=user)
        total=0
        for item in items:
            total+=item.cake.price*item.qty
        request.session["Total"]=total
        return render(request,"cart.html",{"cats":cats,"items":items})

    else:
        action=request.POST["action"]
        cart_id=request.POST["cart_id"]
        item=MyCart.objects.get(id=cart_id)
        if action=="delete":
            item.delete()
        else:

            qty=request.POST["qty"]
            item.qty=qty
            item.save()
        return redirect(home)

def makePayment(request):
    if request.method=="GET":
        return render(request,"makePayment.html") 
    else:
        card_no=request.POST["card_no"]
        cvv=request.POST["cvv"]
        expiry=request.POST["expiry"]
        try:
            user=Payment.objects.get(card_no=card_no,cvv=cvv,expiry=expiry)
        except:
            return redirect(makePayment)
        else:
            total=request.session["Total"]
            if int(user.balance)>total:
                # proceed to make mayment
                owner=Payment.objects.get(card_no=222,cvv=222,expiry=12/2030)
                user.balance-=total
                owner.balance+=total
                user.save()
                owner.save()

            else:
                return HttpResponse("Insufficient Balance")